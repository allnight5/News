package com.example.news.member.dto;

import lombok.Getter;

@Getter
public class MemberRequestDto {
    private String email;
    private String password;
}
