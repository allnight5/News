package com.example.news.member.social;

public interface SocialLoginProvider {
    String getLoginURL();
    String getUserInfo(String code);
    // 기타 로그인에 필요한 메소드들을 선언합니다.
}
