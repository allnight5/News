package com.example.news.member.social;

import com.example.news.member.social.provider.GoogleLoginProvider;
import com.example.news.member.social.provider.KakaoLoginProvider;

import java.util.HashMap;
import java.util.Map;

public class SocialLoginProviderFactory {
    private final Map<String, SocialLoginProvider> providerMap = new HashMap<>();

    public SocialLoginProviderFactory() {
        // 소셜 로그인 제공자를 추가합니다.
        providerMap.put("google", new GoogleLoginProvider());
        providerMap.put("kakao", new KakaoLoginProvider());
        // 다른 소셜 로그인 제공자 추가 가능
    }

    public SocialLoginProvider getSocialLoginProvider(String providerType) {
        return providerMap.get(providerType.toLowerCase());
    }
}
