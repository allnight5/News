package com.example.news.member.social.provider;

import com.example.news.member.social.SocialLoginProvider;

public class KakaoLoginProvider implements SocialLoginProvider {
    @Override
    public String getLoginURL() {
        // 카카오 로그인 URL 생성 로직
        return "https://kauth.kakao.com/login";
    }

    @Override
    public String getUserInfo(String code) {
        // 카카오 사용자 정보 조회 로직
        return "Kakao User Info";
    }
}
