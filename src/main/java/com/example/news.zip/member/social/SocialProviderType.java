package com.example.news.member.social;

public enum SocialProviderType {
    GOOGLE,
    KAKAO
    // 다른 소셜 로그인 제공자 추가 가능
}