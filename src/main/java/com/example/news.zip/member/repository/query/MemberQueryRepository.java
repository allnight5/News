package com.example.news.member.repository.query;

import com.example.news.member.dto.MemberRequestDto;
import com.example.news.member.dto.MemberResponseDto;
import com.example.news.member.entity.Member;

public interface MemberQueryRepository {

    public MemberResponseDto getMemberResponse(MemberRequestDto memberRequestDto);
    public Member getMember(MemberRequestDto memberRequestDto);
}
