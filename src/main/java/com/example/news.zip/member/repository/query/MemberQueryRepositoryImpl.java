package com.example.news.member.repository.query;

import com.example.news.member.dto.MemberRequestDto;
import com.example.news.member.dto.MemberResponseDto;
import com.example.news.member.entity.Member;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.stereotype.Repository;


import java.util.Optional;

import static com.example.news.member.entity.QMember.member;
@Repository
public class MemberQueryRepositoryImpl implements MemberQueryRepository{

    private final JPAQueryFactory jpaQueryFactory;

    public MemberQueryRepositoryImpl(JPAQueryFactory jpaQueryFactory){
        this.jpaQueryFactory = jpaQueryFactory;
    }

    @Override
    public MemberResponseDto getMemberResponse(MemberRequestDto memberRequestDto) {
        Member foundMember = jpaQueryFactory
                .selectFrom(member)
                .where(
                        findByMemberEmail(memberRequestDto.getEmail()),
                        findByMemberPassword(memberRequestDto.getPassword())
                )
                .fetchOne();

        return MemberResponseDto.From(foundMember);
    }

    @Override
    public Member getMember(MemberRequestDto memberRequestDto) {
        return jpaQueryFactory
                .selectFrom(member)
                .where(
                        findByMemberEmail(memberRequestDto.getEmail()),
                        findByMemberPassword(memberRequestDto.getPassword())
                )
                .fetchOne();
    }


    private BooleanExpression findByMemberEmail(String email){
        return Optional.ofNullable(email)
                .map(member.email::eq)
                .orElse(null);
    }

    private BooleanExpression findByMemberPassword(String password){
        return Optional.ofNullable(password)
                .map(member.password::eq)
                .orElse(null);
    }
}
