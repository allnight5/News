package com.example.news.member.controller;

import com.example.news.member.dto.MemberRequestDto;
import com.example.news.member.entity.Member;
import com.example.news.member.service.MemberService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
@RequiredArgsConstructor
public class MemberController {

    public final MemberService memberService;
    @PostMapping("/signup/member")
    public String signUp(@RequestBody MemberRequestDto requestDto,
                         Model model) {
        // 입력된 유저 정보를 데이터베이스에 저장합니다.
        try {
            if (memberService.signup(requestDto)) {
//                return ResponseEntity.ok("성공");
                Member member = Member.From(requestDto);
                model.addAttribute(member);
                return "save-result";
            } else {
                return "fail";
            }
        }catch (Exception e){
            throw new IllegalArgumentException("false signup");
        }
    }

    @GetMapping("/main")
    public String dashboardPage() {
        return "index"; // main.html 또는 dashboard.jsp와 같은 대시보드 페이지 템플릿
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login"; // logins.html 또는 login.jsp와 같은 로그인 페이지 템플릿
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate(); // 세션 정보 삭제
        }
//        return "redirect:/logins.html"; // 로그아웃 시 로그인 페이지로 이동
        return "index";
    }
}
