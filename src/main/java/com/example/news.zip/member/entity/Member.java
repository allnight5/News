package com.example.news.member.entity;

import com.example.news.member.dto.MemberRequestDto;
import com.example.news.member.repository.MemberRepository;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Member {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String email;
    private String password;
    private Role roles = Role.MEMBER;

    public Member(String email, String password) {
        this.email = email;
        this.password = password;
    }


    public static Member From(MemberRequestDto requestDto) {
        return new Member(requestDto.getEmail(), requestDto.getPassword());
    }
    public void setRoles(Role roles){
        this.roles = roles;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public boolean matchPassword(String inputPassword) {
        return this.password.equals(inputPassword);
    }
}
