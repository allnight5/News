package com.example.news.share;

public class timestamp {
}
