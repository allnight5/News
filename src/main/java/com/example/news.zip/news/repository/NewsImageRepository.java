package com.example.news.news.repository;

import com.example.news.news.entity.NewsImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NewsImageRepository extends JpaRepository<NewsImage, Long> {


}
