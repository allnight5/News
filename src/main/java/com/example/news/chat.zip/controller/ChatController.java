package com.example.news.chat.controller;

import com.example.news.chat.dto.ChatMessageDto;
import com.example.news.chat.dto.ChatMessageResponseDto;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.util.HtmlUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class ChatController {

    @MessageMapping("/enter")
    @SendTo("/topic/greetings")
    public ChatMessageResponseDto enter(ChatMessageDto message, StompHeaderAccessor session) throws Exception {
        return new ChatMessageResponseDto(HtmlUtils.htmlEscape(session.getSessionAttributes().get("name") + "님께서 입장하셨습니다!"));
    }
    @MessageMapping("/exit")
    @SendTo("/topic/greetings")
    public ChatMessageResponseDto exit(ChatMessageDto message, StompHeaderAccessor session) throws Exception {
        return new ChatMessageResponseDto(HtmlUtils.htmlEscape(session.getSessionAttributes().get("name") + "님께서 퇴장하셨습니다!"));
    }
    @MessageMapping("/chat")
    @SendTo("/topic/greetings")
    public ChatMessageResponseDto chat(ChatMessageDto message, StompHeaderAccessor session) throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date now = new Date();

        String currentTime = format.format(now);

        System.out.println(currentTime);
        return new ChatMessageResponseDto(HtmlUtils.htmlEscape(session.getSessionAttributes().get("name") + " : "+message.getName()+"["+currentTime+"]"));
    }

}
