package com.example.news.chat.dto;

import lombok.Getter;

@Getter
public class ChatMessageResponseDto {
    private String message;

    public ChatMessageResponseDto(String message){
        this.message = message;
    }
}
