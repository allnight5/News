package com.example.news.member.entity;

public enum Role {
    MEMBER,
    ADMIN
}
