package com.example.news.member.repository;

import com.example.news.member.entity.Member;
import com.example.news.member.repository.query.MemberQueryRepository;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MemberRepository extends JpaRepository<Member, Long>, MemberQueryRepository {
    Member findByEmail(String email);
}
