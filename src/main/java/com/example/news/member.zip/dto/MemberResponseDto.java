package com.example.news.member.dto;

import com.example.news.member.entity.Member;
import lombok.Getter;

@Getter
public class MemberResponseDto {
    private String email;
    private String password;

    private MemberResponseDto(Member member){
        this.email = member.getEmail();
        this.password = member.getPassword();
    }

    public static MemberResponseDto From(Member member){
        return new MemberResponseDto(member);
    }
}
