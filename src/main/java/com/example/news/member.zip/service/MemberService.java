package com.example.news.member.service;

import com.example.news.member.dto.MemberRequestDto;
import com.example.news.member.dto.MemberResponseDto;
import jakarta.servlet.http.HttpServletRequest;

public interface MemberService {

    public boolean signup(MemberRequestDto requestDto);
    public MemberResponseDto login(MemberRequestDto requestDto);
    public String logout(HttpServletRequest request);
}
