package com.example.news.member.service;

import com.example.news.member.dto.MemberRequestDto;
import com.example.news.member.dto.MemberResponseDto;
import com.example.news.member.entity.AuthInfo;
import com.example.news.member.entity.Member;
import com.example.news.member.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.NoSuchElementException;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService{
    private final MemberRepository repository;
    @Override
    public AuthInfo authenticate(MemberRequestDto requestDto) {
        Member member = repository.getMember(requestDto);
        if (member == null) {
            throw new IllegalArgumentException();
        }
        if (!member.matchPassword(member.getPassword())) {
            throw new NoSuchElementException();
        }

        return new AuthInfo(member.getId(), member.getEmail());
    }
}
