package com.example.news.member.service;

import com.example.news.member.dto.MemberRequestDto;
import com.example.news.member.entity.AuthInfo;

import java.util.NoSuchElementException;

public interface AuthService {
    public AuthInfo authenticate(MemberRequestDto requestDto) throws NoSuchElementException;
}
