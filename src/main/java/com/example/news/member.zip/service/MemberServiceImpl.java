package com.example.news.member.service;

import com.example.news.member.dto.MemberRequestDto;
import com.example.news.member.dto.MemberResponseDto;
import com.example.news.member.entity.Member;
import com.example.news.member.repository.MemberRepository;
import com.example.news.member.repository.query.MemberQueryRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.NoSuchElementException;

@Service
@RequiredArgsConstructor
public class MemberServiceImpl implements MemberService{

    private final MemberRepository repository;

    @Override
    @Transactional
    public boolean signup(MemberRequestDto requestDto) {
        Member member = repository.getMember(requestDto);
        if(member == null){
            repository.save(Member.From(requestDto));
            return true;
        }
        return false;
    }

    @Override
    public MemberResponseDto login(MemberRequestDto requestDto) {
        MemberResponseDto member = repository.getMemberResponse(requestDto);

        if(member != null){
            return member;
        }
        return null;
    }

    @Override
    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate(); // 세션 정보 삭제
        }
        return "redirect:/login"; // 로그아웃 시 로그인 페이지로 이동
    }

    public Member authenticateUser(MemberRequestDto requestDto) {
        Member member = repository.getMember(requestDto);
        if (member == null) {
            throw new IllegalArgumentException();
        }
        if (!member.matchPassword(member.getPassword())) {
            throw new NoSuchElementException();
        }
        return member;
    }
}
