package com.example.news.member.social.provider;

import com.example.news.member.social.SocialLoginProvider;

public class GoogleLoginProvider implements SocialLoginProvider {
    @Override
    public String getLoginURL() {
        // 구글 로그인 URL 생성 로직
        return "https://accounts.google.com/login";
    }

    @Override
    public String getUserInfo(String code) {
        // 구글 사용자 정보 조회 로직
        return "Google User Info";
    }
}
