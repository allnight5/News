package com.example.news.member.social.controller;

import com.example.news.member.social.SocialLoginProvider;
import com.example.news.member.social.SocialLoginProviderFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SocialLoginController {
    private SocialLoginProviderFactory providerFactory = new SocialLoginProviderFactory();

    @GetMapping("/ouath2login")
    public String login(@RequestParam String providerType) {
        SocialLoginProvider loginProvider = providerFactory.getSocialLoginProvider(providerType);
        if (loginProvider != null) {
            String loginURL = loginProvider.getLoginURL();
            // 로그인 URL로 리다이렉트하여 소셜 로그인 처리
            return "redirect:" + loginURL;
        }
        return "redirect:/error"; // 에러 페이지로 리다이렉트
    }

    // 로그인 이후 콜백 URL 처리
    @GetMapping("/callback")
    public String callback(@RequestParam String code, @RequestParam String providerType) {
        SocialLoginProvider loginProvider = providerFactory.getSocialLoginProvider(providerType);
        if (loginProvider != null) {
            String userInfo = loginProvider.getUserInfo(code);
            // 사용자 정보를 처리하고 로그인 성공 후 처리하는 로직
            return "redirect:/dashboard";
        }
        return "redirect:/error"; // 에러 페이지로 리다이렉트
    }
}
